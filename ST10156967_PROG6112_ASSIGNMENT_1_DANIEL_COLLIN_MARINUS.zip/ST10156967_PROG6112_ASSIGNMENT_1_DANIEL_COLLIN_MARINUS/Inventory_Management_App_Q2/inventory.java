import java.util.ArrayList;

public class Inventory {
    private ArrayList<Product> products = new ArrayList<>();

    public void addProduct(Product product) {
        products.add(product);
    }

    public Product searchProduct(String id) {
        for (Product product : products) {
            if (product.getId().equals(id)) {
                return product;
            }
        }
        return null;
    }

    public void sellProduct(String id, int quantity) {
        Product product = searchProduct(id);
        if (product != null && product.getQuantity() >= quantity) {
            product.setQuantity(product.getQuantity() - quantity);
        } else {
            System.out.println("Product not found or insufficient quantity.");
        }
    }

    public void printReport() {
        for (Product product : products) {
            System.out.println(product);
            System.out.println();
        }
    }
}

import java.util.Scanner;

public class InventoryManagementApp {
    private static Inventory inventory = new Inventory();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("INVENTORY MANAGEMENT APPLICATION");
            System.out.println("Enter (1) to launch menu or any other key to exit");
            String choice = scanner.nextLine();

            if (!choice.equals("1")) break;

            System.out.println("Please select one of the following menu items:");
            System.out.println("(1) Add a new product.");
            System.out.println("(2) Search for a product.");
            System.out.println("(3) Sell a product.");
            System.out.println("(4) Print inventory report.");
            System.out.println("(5) Exit Application.");

            choice = scanner.nextLine();
            switch (choice) {
                case "1":
                    addProduct();
                    break;
                case "2":
                    searchProduct();
                    break;
                case "3":
                    sellProduct();
                    break;
                case "4":
                    printInventoryReport();
                    break;
                case "5":
                    System.out.println("Exiting application.");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addProduct() {
        System.out.print("Enter the product id: ");
        String id = scanner.nextLine();
        System.out.print("Enter the product name: ");
        String name = scanner.nextLine();
        System.out.print("Enter the product price: ");
        double price = Double.parseDouble(scanner.nextLine());
        System.out.print("Enter the product quantity: ");
        int quantity = Integer.parseInt(scanner.nextLine());

        Product product = new Product(id, name, price, quantity);
        inventory.addProduct(product);
        System.out.println("Product has been successfully added.");
    }

    private static void searchProduct() {
        System.out.print("Enter the product id to search: ");
        String id = scanner.nextLine();
        Product product = inventory.searchProduct(id);
        if (product != null) {
            System.out.println(product);
        } else {
            System.out.println("Product with Product Id: " + id + " was not found!");
        }
    }

    private static void sellProduct() {
        System.out.print("Enter the product id to sell: ");
        String id = scanner.nextLine();
        System.out.print("Enter the quantity to sell: ");
        int quantity = Integer.parseInt(scanner.nextLine());
        inventory.sellProduct(id, quantity);
    }

    private static void printInventoryReport() {
        inventory.printReport();
    }
}

public class Student {
    private String id;
    private String name;
    private int age;
    private String email;
    private String course;

    public Student(String id, String name, int age, String email, String course) {
        this.id = id;
        this.name = name;
        setAge(age);
        this.email = email;
        this.course = course;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getAge() { return age; }
    public void setAge(int age) {
        if (age >= 16) this.age = age;
        else System.out.println("Invalid age, must be >= 16");
    }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getCourse() { return course; }
    public void setCourse(String course) { this.course = course; }

    @Override
    public String toString() {
        return String.format("STUDENT ID: %s\nSTUDENT NAME: %s\nSTUDENT AGE: %d\nSTUDENT EMAIL: %s\nSTUDENT COURSE: %s",
                             id, name, age, email, course);
    }
}
